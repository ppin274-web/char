# 중립 Android 카톡테마 템플릿 (everwise)

카카오 공식 Android 샘플(어피치, 26.1.0)의 **빌드 가능한 프로젝트 구조**를 바탕으로,
어피치 아트와 apeach 브랜딩을 제거하고 **everwise 기준**으로 재브랜딩한 중립 템플릿.
`.ktheme → Android` 컨버터가 이 템플릿을 복사해 색·이미지만 갈아끼운다.

## 무엇이 바뀌었나

- **정체성 → everwise**: `namespace`/`applicationId`/매니페스트 package/Java 패키지/표시명(`theme_title`·`app_name`) 전부 `com.kakao.talk.theme.everwise` / `everwise`.
- **어피치 아트 제거**: 78개 PNG를 전부 중립 플레이스홀더로 교체(`make_neutral_assets.py`). 치수는 원본 유지. 실제 테마 이미지는 변환 시점에 studio `generate.js`/사용자 편집분으로 덮어써진다.

## 유지된 `com.kakao.talk.*` (절대 바꾸지 말 것 — 기능 식별자)

이걸 바꾸면 테마가 카카오톡에 인식되지 않는다:

- `uses-permission com.kakao.talk.v2.theme` — 테마 권한
- `<queries><package com.kakao.talk>` — 실제 카톡 앱 조회
- 인텐트 액션 `com.kakao.talk.theme.action.MAIN` — 카톡의 테마 탐색 신호
- `kakaotalk://settings/theme/` URI, `KAKAOTALK_PACKAGE_NAME` — 카톡 설정 열기/설치 확인
- **appId 접두사 `com.kakao.talk.theme.`** — 카톡 테마 규약 (접미사만 테마별로 변경)

## 빌드 (APK)

```bash
# local.properties에 Android SDK 경로 필요 (예: sdk.dir=/Users/<you>/Library/Android/sdk)
./gradlew assembleRelease
# 서명: Android Studio에서 keystore로 서명하거나 signingConfig 추가
```

- 플레이스홀더 상태로도 빌드는 되지만 화면은 회색 기본값. 실제 사용은 컨버터로 테마를 씌운 결과물을 빌드.
- `.9.png`는 aapt가 컴파일 시 나인패치 규칙을 검증하므로, 컨버터 출력이 이 검증을 통과하는지 최초 1회 확인 권장.
