# 챠미키티 Android 테마 - 휴대폰에서 APK 빌드하기

이 프로젝트는 GitHub Actions에서 Android APK를 빌드하도록 준비되어 있습니다.

1. GitHub 계정을 만들고 로그인합니다.
2. 새 Repository를 만들고 이 ZIP의 압축을 풀어 나온 파일/폴더를 저장소 최상위에 업로드합니다. (KakaoTheme 폴더와 .github 폴더가 최상위에 있어야 합니다.)
3. 저장소의 Actions 탭에서 워크플로 사용을 허용합니다.
4. Actions → Build Android KakaoTalk theme → Run workflow를 누릅니다.
5. 빌드가 끝나면 실행 기록 아래 Artifacts에서 CharmiKitty-Android-APK를 내려받아 압축을 풀고 APK를 설치합니다.

주의: 빌드 성공과 실제 카카오톡 최신 버전에서의 호환성은 별개이며, 설치 시 Android에서 출처를 알 수 없는 앱 설치 허용을 요청할 수 있습니다.
